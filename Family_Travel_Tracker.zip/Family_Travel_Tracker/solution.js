
import express from "express";
import bodyParser from "body-parser";
import pg from "pg";
import bcrypt from "bcrypt";

const app = express();
const port = 3002;
const saltRounds = 10;


const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "world",
  password: "280802",
  port: 5432,
});
db.connect();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

let currentUserId = 1;

let users = [];

async function checkVisisted() {
  const result = await db.query(
    "SELECT country_code FROM visited_countries JOIN users ON users.id = user_id WHERE user_id = $1; ",
    [currentUserId]
  );
  let countries = [];
  result.rows.forEach((country) => {
    countries.push(country.country_code);
  });
  return countries;
}

async function getCurrentUser() {
  const result = await db.query("SELECT * FROM users");
  users = result.rows;

  // Find the user matching currentUserId
  let currentUser = users.find((user) => user.id == currentUserId);

  // If no match, default to the first user in the database
  if (!currentUser && users.length > 0) {
    currentUser = users[0];
    currentUserId = currentUser.id; // Update currentUserId to the first user's ID
  }

  return currentUser;
}


// HOME
app.get("/", async (req, res) => {
  res.render("home.ejs");
});
app.get("/main", async (req, res) => {
  const countries = await checkVisisted();
  const currentUser = await getCurrentUser();

  res.render("index.ejs", {
    countries: countries,
    total: countries.length,
    users: users,
    color: currentUser.color,
  });
});


// AUTHEN
app.get("/login", (req, res) => {
  res.render("login.ejs");
});

app.get("/register", (req, res) => {
  res.render("register.ejs");
});

app.post("/register", async (req, res) => {
  const countries = await checkVisisted();
  const currentUser = await getCurrentUser();

  try {
    const checkResult = await db.query("SELECT * FROM auth WHERE email = $1", [
      email,
    ]);

    if (checkResult.rows.length > 0) {
      res.send("Email already exists. Try logging in.");
    } else {
      //hashing the password and saving it in the database
      bcrypt.hash(password, saltRounds, async (err, hash) => {
        if (err) {
          console.error("Error hashing password:", err);
        } else {
          console.log("Hashed Password:", hash);
          await db.query(
            "INSERT INTO auth (email, password) VALUES ($1, $2)",
            [email, hash]
          );
          res.render("/main");
        }
      });
    }
  } catch (err) {
    console.log(err);
  }

  
});

app.post("/login", async (req, res) => {
  const email = req.body.username;
  const loginPassword = req.body.password;

  try {
    const result = await db.query("SELECT * FROM auth WHERE email = $1", [
      email,
    ]);
    if (result.rows.length > 0) {
      const user = result.rows[0];
      const storedHashedPassword = user.password;
      //verifying the password
      bcrypt.compare(loginPassword, storedHashedPassword, (err, result) => {
        if (err) {
          console.error("Error comparing passwords:", err);
        } else {
          if (result) {
            res.redirect("/main");
          } else {
            res.send("Incorrect Password");
          }
        }
      });
    } else {
      res.send("User not found");
    }
  } catch (err) {
    console.log(err);
  }
});


// MAIN
app.post("/add", async (req, res) => {
  const input = req.body["country"];
  const currentUser = await getCurrentUser();

  try {
    const result = await db.query(
      "SELECT country_code FROM countries WHERE LOWER(country_name) LIKE '%' || $1 || '%';",
      [input.toLowerCase()]
    );

    const data = result.rows[0];
    const countryCode = data.country_code;
    try {
      await db.query(
        "INSERT INTO visited_countries (country_code, user_id) VALUES ($1, $2)",
        [countryCode, currentUserId]
      );
      res.redirect("/main");
    } catch (err) {
      console.log(err);
    }
  } catch (err) {
    console.log(err);
  }
});
// DELETE
app.post("/delete", async (req, res) => {
  const countryCode = req.body.country_code;
  
  try {
    await db.query(
      "DELETE FROM visited_countries WHERE country_code = $1 AND user_id = $2;",
      [countryCode, currentUserId]
    );
    res.redirect("/main");
  } catch (err) {
    console.log(err);
  }
});

app.post("/delete_user", async (req, res) => {
  const { user_name } = req.body; // Extract user_name from the form

  try {
    if (!user_name) {
      console.error("User name is missing in the request body.");
      return res.status(400).send("User name is required.");
    }

    console.log(`Attempting to delete user with name: ${user_name}`);

    // First, delete related records in visited_countries
    await db.query("DELETE FROM visited_countries WHERE user_id = (SELECT id FROM users WHERE name = $1)", [user_name]);

    // Then, delete the user from the users table
    const result = await db.query("DELETE FROM users WHERE name = $1", [user_name]);

    if (result.rowCount === 0) {
      console.error("No user found with the given name.");
      return res.status(404).send("User not found.");
    }

    console.log("User deleted successfully.");
    res.redirect("/main"); // Redirect to the main page after deletion
  } catch (error) {
    console.error("Error deleting user:", error);
    res.status(500).send("An error occurred while deleting the user.");
  }
});


app.post("/user", async (req, res) => {
  if (req.body.add === "new") {
    res.render("new.ejs");
  } else {
    currentUserId = req.body.user;
    res.redirect("/main");
  }
});

app.post("/new", async (req, res) => {
  const name = req.body.name;
  const color = req.body.color;

  const result = await db.query(
    "INSERT INTO users (name, color) VALUES($1, $2) RETURNING *;",
    [name, color]
  );

  const id = result.rows[0].id;
  currentUserId = id;

  res.redirect("/main");
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});


